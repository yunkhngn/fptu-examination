chrome.runtime.onInstalled.addListener(() => {
  console.log("FPTU Exam Exporter loaded");
});